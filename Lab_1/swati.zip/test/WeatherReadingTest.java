import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import weather.WeatherReading;

/**
 * Test cases for Weather Reading class.
 * */
public class WeatherReadingTest {

  private WeatherReading day1;

  @Test
  public void setupTest() {
    day1 = new WeatherReading(101, 95, 100, 220);
    assertEquals("Reading: T = 101, D = 95, v = 100, rain = 220", day1.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNegWindSpeed() {
    day1 = new WeatherReading(101, 95, -100,220);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNegTotalRain() {
    day1 = new WeatherReading(101, 95, 100, -220);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testDewPointCondition() {
    day1 = new WeatherReading(101, 104, 100, 220);
  }

  @Before
  public void setDay1() {
    day1 = new WeatherReading(102, 96, 100, 220);
  }

  @Test
  public void testGetTemperature() {
    assertEquals(102, day1.getTemperature(),0);
  }

  @Test
  public void testGetDewPoint() {
    assertEquals(96, day1.getDewPoint(),0);
  }

  @Test
  public void testGetWindSpeed() {
    assertEquals(100, day1.getWindSpeed(),0);
  }

  @Test
  public void testGetTotalRain() {
    assertEquals(220, day1.getTotalRain(),0);
  }

  @Test
  public void testGetRelativeHumidity() {
    assertEquals(70, day1.getRelativeHumidity(),0);
  }

  @Test
  public void testGetHeatIndex() {
    assertEquals(858, day1.getHeatIndex(),0);
  }

  @Test
  public void testGetWindChill() {
    assertEquals(286, day1.getWindChill(),0);
  }

}
